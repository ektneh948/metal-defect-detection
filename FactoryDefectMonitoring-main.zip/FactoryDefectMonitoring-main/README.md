<div align="center">

<!-- logo -->
<img src="images/스마트팩토리1.jpg" alt="설명" style="width: 400px; height: auto;">
<img src="images/스마트팩토리2.jpg" alt="설명" style="width: 400px; height: auto;">

# 🏭공장 표면 결함 검사 모니터링🔍

[<img src="https://img.shields.io/badge/-readme.md-important?style=flat&logo=google-chrome&logoColor=white" />]() [<img src="https://img.shields.io/badge/-tech blog-blue?style=flat&logo=google-chrome&logoColor=white" />]() [<img src="https://img.shields.io/badge/release-v0.0.0-yellow?style=flat&logo=google-chrome&logoColor=white" />]() 
<br/> [<img src="https://img.shields.io/badge/프로젝트 기간-2023.4 ~ 2024.12 -green?style=flat&logo=&logoColor=white" />]()
</div> 

<br />
<div align="center">
<img src="images/과정1.png" alt="설명" style="width: 700px; height: auto;">
</div> 
<br />

## 📜 프로젝트 개요
스마트 팩토리에서 육안 검사의 한계와 데이터 확보 어렵닫는 점, 새로운 품질 조건이나, 환경이 바뀔 때 마다 새로 데이터를 확보해야 한다는 문제를 개선하고자 프로젝트를 진행하게 되었습니다.

<br />


## 🛠️프로젝트 진행과정


<img src="images/그림01.jpg" alt="설명" style="width: 400px; height: auto;">

<br />
<img src="images/그림02.jpg" alt="설명" style="width: 400px; height: auto;">

<br />
<img src="images/그림03.jpg" alt="설명" style="width: 400px; height: auto;">

<br />
<img src="images/그림04.png" alt="설명" style="width: 400px; height: auto;">


<br />



## 📝 ERD 설계
<img src="images/Untitled (1).png" alt="설명" style="width: 600px; height: auto;">
<br />
